# app.py
from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score
from sklearn.preprocessing import LabelEncoder
import io
import time
import numpy as np

app = Flask(__name__)
CORS(app)

# Global variables for trained models and settings
trained_models = {}       # {"Model1": model1, "Model2": model2}
model_mode = "regression" # either "regression" or "classification"
label_encoder = None      # used if target is non-numeric
prediction_schema = []    # prediction schema built solely from the selected independent features

def build_prediction_schema(df, features):
    """
    Build a prediction schema from the originally selected independent features.
    For each feature, if numeric, record type "numeric".
    Otherwise, record type "categorical" along with its unique options and expected dummy column names.
    """
    schema = []
    for col in features:
        try:
            pd.to_numeric(df[col])
            schema.append({"name": col, "type": "numeric"})
        except Exception:
            df[col] = df[col].astype(str)
            options = df[col].unique().tolist()
            dummy_columns = [f"{col}_{opt}" for opt in options]
            schema.append({
                "name": col,
                "type": "categorical",
                "options": options,
                "dummy_columns": dummy_columns
            })
    return schema

def process_features(df, features):
    """
    Process only the selected independent features.
    For numeric features, convert to numeric.
    For categorical features, perform one-hot encoding.
    Return the modified dataframe and the list of processed feature names.
    """
    processed_features = []
    for col in features:
        try:
            df[col] = pd.to_numeric(df[col], errors='raise')
            processed_features.append(col)
        except Exception:
            df[col] = df[col].astype(str)
            dummies = pd.get_dummies(df[col], prefix=col)
            processed_features.extend(dummies.columns.tolist())
            df = pd.concat([df, dummies], axis=1)
            df.drop(columns=[col], inplace=True)
    return df, processed_features

def train_and_evaluate(X_train, X_test, y_train, y_test, feature_names, is_regression=True):
    results = {}
    if is_regression:
        lr = LinearRegression()
        start_time = time.time()
        lr.fit(X_train, y_train)
        lr_time = time.time() - start_time
        pred_lr = lr.predict(X_test)
        mse_lr = mean_squared_error(y_test, pred_lr)
        r2_lr = r2_score(y_test, pred_lr)
        results["Linear Regression"] = {
            "MSE": round(mse_lr, 4),
            "R2 Score": round(r2_lr, 4),
            "Training Time": round(lr_time, 4)
        }
        rf = RandomForestRegressor(n_estimators=100)
        start_time = time.time()
        rf.fit(X_train, y_train)
        rf_time = time.time() - start_time
        pred_rf = rf.predict(X_test)
        mse_rf = mean_squared_error(y_test, pred_rf)
        r2_rf = r2_score(y_test, pred_rf)
        rf_result = {
            "MSE": round(mse_rf, 4),
            "R2 Score": round(r2_rf, 4),
            "Training Time": round(rf_time, 4)
        }
        if feature_names is not None:
            importances = rf.feature_importances_
            rf_result["Feature Importance"] = {name: round(imp, 4) for name, imp in zip(feature_names, importances)}
        results["Random Forest"] = rf_result
        results["Predictions"] = {
            "Actual": y_test.tolist(),
            "Linear Regression": pred_lr.tolist(),
            "Random Forest": pred_rf.tolist()
        }
        return results, lr, rf
    else:
        lr = LogisticRegression(max_iter=1000)
        start_time = time.time()
        lr.fit(X_train, y_train)
        lr_time = time.time() - start_time
        pred_lr = lr.predict(X_test)
        acc_lr = accuracy_score(y_test, pred_lr)
        results["Logistic Regression"] = {
            "Accuracy": round(acc_lr, 4),
            "Training Time": round(lr_time, 4)
        }
        rf = RandomForestClassifier(n_estimators=100)
        start_time = time.time()
        rf.fit(X_train, y_train)
        rf_time = time.time() - start_time
        pred_rf = rf.predict(X_test)
        acc_rf = accuracy_score(y_test, pred_rf)
        results["Random Forest"] = {
            "Accuracy": round(acc_rf, 4),
            "Training Time": round(rf_time, 4)
        }
        results["Predictions"] = {
            "Actual": y_test.tolist(),
            "Logistic Regression": pred_lr.tolist(),
            "Random Forest": pred_rf.tolist()
        }
        return results, lr, rf

@app.route('/compare', methods=['GET'])
def compare_models():
    """
    Iris dataset comparison endpoint.
    Accepts query parameters:
      - target: name of the target column.
      - features: list of independent features.
    If target equals "species", a species column is created from iris.target.
    Defaults: if not provided, target = first measurement, features = remaining measurements.
    """
    global trained_models, prediction_schema, model_mode, label_encoder
    try:
        iris = load_iris()
        df = pd.DataFrame(iris.data, columns=iris.feature_names)
        # Get query parameters
        target = request.args.get('target')
        features = request.args.getlist('features')
        # If target equals "species", create species column and use classification mode.
        if target == "species":
            df["species"] = [iris.target_names[t] for t in iris.target]
            target = "species"
            if not features:
                features = iris.feature_names  # use all measurements as features
        else:
            if not target or target not in df.columns:
                target = iris.feature_names[0]
            if not features:
                features = [col for col in df.columns if col != target]
        # Determine regression vs classification
        is_regression = True
        try:
            df[target] = pd.to_numeric(df[target], errors='raise')
        except Exception:
            is_regression = False
            le = LabelEncoder()
            df[target] = le.fit_transform(df[target])
            label_encoder = le
        model_mode = "regression" if is_regression else "classification"
        # Build prediction schema from selected independent features
        prediction_schema = build_prediction_schema(df, features)
        X = df[features].values
        y = df[target].values
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        results, m1, m2 = train_and_evaluate(X_train, X_test, y_train, y_test, features, is_regression)
        trained_models["Model1"] = m1
        trained_models["Model2"] = m2
        preview = df.head(5).to_dict(orient='records')
        return jsonify({
            "success": True,
            "results": results,
            "data_preview": preview,
            "columns": df.columns.tolist(),
            "features_used": features,
            "prediction_schema": prediction_schema
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/upload', methods=['POST'])
def handle_upload():
    """
    Custom dataset upload endpoint.
    Expects:
      - A CSV file.
      - A 'target' field for the target column.
      - One or more 'features' fields for independent features.
    Defaults to the last column as target if not provided.
    If no independent features are provided, returns an error.
    Builds the model only on the selected independent features.
    If the target is non-numeric, applies label encoding and uses classification mode.
    Categorical independent features are one-hot encoded.
    Returns a prediction_schema built solely from the selected independent features.
    """
    global trained_models, prediction_schema, model_mode, label_encoder
    try:
        if 'file' not in request.files:
            return jsonify({"success": False, "error": "No file uploaded"}), 400
        file = request.files['file']
        if not file.filename.endswith('.csv'):
            return jsonify({"success": False, "error": "Only CSV files accepted"}), 400
        file_content = file.stream.read().decode('utf-8')
        df = pd.read_csv(io.StringIO(file_content))
        if df.shape[1] < 2:
            return jsonify({"success": False, "error": "CSV must have at least 2 columns"}), 400

        target = request.form.get("target")
        features = request.form.getlist("features")
        if target is None or target not in df.columns:
            target = df.columns[-1]
            features = list(df.columns[:-1])
        else:
            if not features:
                features = [col for col in df.columns if col != target]

        is_regression = True
        try:
            df[target] = pd.to_numeric(df[target], errors='raise')
        except Exception:
            is_regression = False
            le = LabelEncoder()
            df[target] = le.fit_transform(df[target])
            label_encoder = le
        model_mode = "regression" if is_regression else "classification"

        prediction_schema = build_prediction_schema(df, features)
        df, processed_features = process_features(df, features)
        X = df[processed_features].values
        y = df[target].values
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        results, m1, m2 = train_and_evaluate(X_train, X_test, y_train, y_test, processed_features, is_regression)
        trained_models["Model1"] = m1
        trained_models["Model2"] = m2
        preview = df.head(5).to_dict(orient='records')
        return jsonify({
            "success": True,
            "results": results,
            "data_preview": preview,
            "columns": df.columns.tolist(),
            "features_used": processed_features,
            "prediction_schema": prediction_schema
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/predict', methods=['POST'])
def predict():
    """
    Prediction endpoint.
    Expects a JSON payload with a "features" object mapping the originally selected independent feature names
    to user-provided values.
    For numeric features, the value is used directly.
    For categorical features, one-hot encoding is applied using the dummy columns in the prediction_schema.
    """
    global trained_models, prediction_schema, model_mode, label_encoder
    try:
        data = request.json
        if not data or "features" not in data:
            return jsonify({"success": False, "error": "Please provide feature values"}), 400
        input_features = data["features"]
        feature_vector = []
        for item in prediction_schema:
            name = item["name"]
            if item["type"] == "numeric":
                try:
                    value = float(input_features.get(name, 0))
                except Exception:
                    return jsonify({"success": False, "error": f"Invalid numeric value for {name}"}), 400
                feature_vector.append(value)
            elif item["type"] == "categorical":
                selected = str(input_features.get(name, ""))
                for dummy in item["dummy_columns"]:
                    feature_vector.append(1 if dummy == f"{name}_{selected}" else 0)
            else:
                return jsonify({"success": False, "error": f"Unknown feature type for {name}"}), 400
        feature_vector = np.array(feature_vector).reshape(1, -1)
        model1 = trained_models.get("Model1")
        model2 = trained_models.get("Model2")
        if model1 is None or model2 is None:
            return jsonify({"success": False, "error": "Models not trained yet. Please run a model comparison first."}), 400
        pred1 = model1.predict(feature_vector)
        pred2 = model2.predict(feature_vector)
        if model_mode == "classification" and label_encoder is not None:
            pred1 = label_encoder.inverse_transform(pred1.astype(int))
            pred2 = label_encoder.inverse_transform(pred2.astype(int))
        return jsonify({
            "success": True,
            "predictions": {
                "Linear Regression": pred1[0],
                "Random Forest": pred2[0]
            }
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
