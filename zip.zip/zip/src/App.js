// App.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import {
  CssBaseline,
  Container,
  Box,
  Button,
  Typography,
  CircularProgress,
  Paper,
  Snackbar,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  OutlinedInput,
  Checkbox,
  ListItemText,
  TextField
} from '@mui/material';
import { Alert } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { Bar, Scatter, Line } from 'react-chartjs-2';
import 'chart.js/auto';

// Combined Drag-and-Drop / File Picker Component
const CombinedDragDrop = ({ onFileSelect }) => {
  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) onFileSelect(file);
  };
  const handleDragOver = (e) => e.preventDefault();
  const handleClick = () => {
    document.getElementById('csv-upload').click();
  };
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) onFileSelect(file);
  };
  return (
    <Box
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onClick={handleClick}
      sx={{
        border: '2px dashed',
        borderColor: 'grey.500',
        borderRadius: 1,
        p: 2,
        textAlign: 'center',
        cursor: 'pointer'
      }}
    >
      <Typography variant="body1">
        Drag and drop your CSV file here, or click to select one
      </Typography>
      <input
        accept=".csv"
        id="csv-upload"
        type="file"
        style={{ display: 'none' }}
        onChange={handleFileChange}
      />
    </Box>
  );
};

const App = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Custom dataset upload states
  const [uploadedFile, setUploadedFile] = useState(null);
  const [columns, setColumns] = useState([]);
  const [previewData, setPreviewData] = useState([]);
  const [targetColumn, setTargetColumn] = useState('');
  const [selectedFeatures, setSelectedFeatures] = useState([]);

  // Prediction state for custom dataset
  const [predictionSchema, setPredictionSchema] = useState([]);
  const [predictionValues, setPredictionValues] = useState({});
  const [predictionResult, setPredictionResult] = useState(null);

  // Iris dataset comparison states
  const irisCols = [
    "sepal length (cm)",
    "sepal width (cm)",
    "petal length (cm)",
    "petal width (cm)"
  ];
  const [irisTarget, setIrisTarget] = useState("sepal length (cm)");
  const [irisFeatures, setIrisFeatures] = useState(["sepal width (cm)", "petal length (cm)", "petal width (cm)"]);

  const theme = createTheme({
    palette: { mode: darkMode ? 'dark' : 'light' }
  });

  // When a new custom file is uploaded, clear previous selections.
  useEffect(() => {
    setSelectedFeatures([]);
    setPredictionSchema([]);
    setPredictionValues({});
  }, [uploadedFile]);

  // Ensure custom dataset target is removed from selectedFeatures.
  useEffect(() => {
    setSelectedFeatures(prev => prev.filter(col => col !== targetColumn));
  }, [targetColumn]);

  // Handle custom file selection via CombinedDragDrop.
  const handleFileSelect = (file) => {
    if (!file) return;
    setUploadedFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      const lines = text.split('\n').filter(line => line.trim() !== '');
      if (lines.length === 0) return;
      const header = lines[0].split(',');
      setColumns(header);
      // Default: last column as target.
      setTargetColumn(header[header.length - 1]);
      // Auto-select remaining columns as features.
      setSelectedFeatures(header.slice(0, header.length - 1));
      const preview = lines.slice(1, 6).map(line => {
        const values = line.split(',');
        let obj = {};
        header.forEach((col, index) => { obj[col] = values[index]; });
        return obj;
      });
      setPreviewData(preview);
    };
    reader.readAsText(file);
  };

  // Handler for Iris dataset comparison.
  // Sends query parameters for target and features.
  const handleCompareIris = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:5000/compare', {
        params: { target: irisTarget, features: irisFeatures }
      });
      setResults(response.data.results);
      if (response.data.prediction_schema) {
        setPredictionSchema(response.data.prediction_schema);
        const initVals = {};
        response.data.prediction_schema.forEach(item => { initVals[item.name] = ""; });
        setPredictionValues(initVals);
      }
      setError(null);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to compare models');
    } finally {
      setLoading(false);
    }
  };

  // Handler for custom dataset training.
  const handleCustomTrain = async () => {
    if (!uploadedFile) return;
    try {
      setLoading(true);
      const formData = new FormData();
      formData.append('file', uploadedFile);
      formData.append('target', targetColumn);
      // Send only the selected independent features.
      selectedFeatures.forEach(feature => formData.append('features', feature));
      const response = await axios.post('http://localhost:5000/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setResults(response.data.results);
      if (response.data.prediction_schema) {
        setPredictionSchema(response.data.prediction_schema);
        const initVals = {};
        response.data.prediction_schema.forEach(item => { initVals[item.name] = ""; });
        setPredictionValues(initVals);
      }
      setError(null);
    } catch (err) {
      setError(err.response?.data?.error || 'File upload failed');
    } finally {
      setLoading(false);
    }
  };

  // Download report.
  const handleDownload = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(results, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "model_comparison_report.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Handle changes in prediction input fields.
  const handlePredictionInputChange = (feature, value) => {
    setPredictionValues(prev => ({ ...prev, [feature]: value }));
  };

  // Send prediction request.
  const handlePredict = async () => {
    try {
      const response = await axios.post('http://localhost:5000/predict', { features: predictionValues });
      if (response.data.success) {
        setPredictionResult(response.data.predictions);
        setError(null);
      } else {
        setError(response.data.error || 'Prediction failed');
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Prediction failed');
    }
  };

  // Prepare Chart.js data if results exist.
  let barChartData, scatterData, lineData, featureBarData;
  if (results) {
    barChartData = {
      labels: ['MSE', 'R2 Score', 'Training Time'],
      datasets: [
        {
          label: 'Linear Regression',
          data: [
            results["Linear Regression"].MSE,
            results["Linear Regression"]["R2 Score"],
            results["Linear Regression"]["Training Time"]
          ],
          backgroundColor: 'rgba(75, 192, 192, 0.6)'
        },
        {
          label: 'Random Forest',
          data: [
            results["Random Forest"].MSE,
            results["Random Forest"]["R2 Score"],
            results["Random Forest"]["Training Time"]
          ],
          backgroundColor: 'rgba(153, 102, 255, 0.6)'
        }
      ]
    };
    scatterData = {
      datasets: [
        {
          label: 'Linear Regression',
          data: results.Predictions.Actual.map((act, i) => ({
            x: act,
            y: results.Predictions["Linear Regression"][i]
          })),
          backgroundColor: 'rgba(75, 192, 192, 0.6)'
        },
        {
          label: 'Random Forest',
          data: results.Predictions.Actual.map((act, i) => ({
            x: act,
            y: results.Predictions["Random Forest"][i]
          })),
          backgroundColor: 'rgba(153, 102, 255, 0.6)'
        }
      ]
    };
    lineData = {
      labels: results.Predictions.Actual.map((_, i) => i + 1),
      datasets: [
        {
          label: 'Actual',
          data: results.Predictions.Actual,
          borderColor: 'rgba(0,0,0,0.6)',
          fill: false
        },
        {
          label: 'Linear Regression',
          data: results.Predictions["Linear Regression"],
          borderColor: 'rgba(75, 192, 192, 0.6)',
          fill: false
        },
        {
          label: 'Random Forest',
          data: results.Predictions["Random Forest"],
          borderColor: 'rgba(153, 102, 255, 0.6)',
          fill: false
        }
      ]
    };
    if (results["Random Forest"].hasOwnProperty("Feature Importance")) {
      const importance = results["Random Forest"]["Feature Importance"];
      featureBarData = {
        labels: Object.keys(importance),
        datasets: [
          {
            label: 'Feature Importance',
            data: Object.values(importance),
            backgroundColor: 'rgba(255, 159, 64, 0.6)'
          }
        ]
      };
    }
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container maxWidth="md" sx={{ py: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 4 }}>
          <Typography variant="h4">ML Model Comparator</Typography>
          <Button variant="outlined" onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? 'Light Mode' : 'Dark Mode'}
          </Button>
        </Box>

        {/* Iris Dataset Comparison Section */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" gutterBottom>Iris Dataset Comparison</Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mb: 2 }}>
            <FormControl sx={{ minWidth: 180 }}>
              <InputLabel id="iris-target-label">Target Column</InputLabel>
              <Select
                labelId="iris-target-label"
                value={irisTarget}
                label="Target Column"
                onChange={(e) => setIrisTarget(e.target.value)}
              >
                {irisCols.map(col => (
                  <MenuItem key={col} value={col}>{col}</MenuItem>
                ))}
                <MenuItem value="species">species</MenuItem>
              </Select>
            </FormControl>
            <FormControl sx={{ minWidth: 300 }}>
              <InputLabel id="iris-features-label">Independent Features</InputLabel>
              <Select
                labelId="iris-features-label"
                multiple
                value={irisFeatures}
                onChange={(e) => setIrisFeatures(e.target.value)}
                input={<OutlinedInput label="Independent Features" />}
                renderValue={(selected) => selected.join(', ')}
              >
                {irisCols.filter(col => col !== irisTarget).map(col => (
                  <MenuItem key={col} value={col}>
                    <Checkbox checked={irisFeatures.indexOf(col) > -1} />
                    <ListItemText primary={col} />
                  </MenuItem>
                ))}
                {irisTarget === "species" &&
                  irisCols.map(col => (
                    <MenuItem key={col} value={col}>
                      <Checkbox checked={irisFeatures.indexOf(col) > -1} />
                      <ListItemText primary={col} />
                    </MenuItem>
                  ))
                }
              </Select>
            </FormControl>
          </Box>
          <Button variant="contained" onClick={handleCompareIris} disabled={loading}>
            Compare Models on Iris Dataset
          </Button>
        </Paper>

        {/* Custom Dataset Upload Section */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" gutterBottom>Custom Dataset</Typography>
          <CombinedDragDrop onFileSelect={handleFileSelect} />
        </Paper>

        {/* CSV Preview & Selection Controls for Custom Dataset */}
        {columns.length > 0 && (
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>CSV Preview</Typography>
            <TableContainer component={Paper} sx={{ maxHeight: 300 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    {columns.map(col => <TableCell key={col}>{col}</TableCell>)}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {previewData.map((row, idx) => (
                    <TableRow key={idx}>
                      {columns.map(col => <TableCell key={col}>{row[col]}</TableCell>)}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Box sx={{ mt: 2, display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <FormControl sx={{ minWidth: 150 }}>
                <InputLabel id="target-select-label">Target Column</InputLabel>
                <Select
                  labelId="target-select-label"
                  value={targetColumn}
                  label="Target Column"
                  onChange={(e) => setTargetColumn(e.target.value)}
                >
                  {columns.map(col => (
                    <MenuItem key={col} value={col}>{col}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl sx={{ minWidth: 250 }}>
                <InputLabel id="features-select-label">Independent Features</InputLabel>
                <Select
                  labelId="features-select-label"
                  multiple
                  value={selectedFeatures}
                  onChange={(e) => setSelectedFeatures(e.target.value)}
                  input={<OutlinedInput label="Independent Features" />}
                  renderValue={(selected) => selected.join(', ')}
                >
                  {columns.filter(col => col !== targetColumn).map(col => (
                    <MenuItem key={col} value={col}>
                      <Checkbox checked={selectedFeatures.indexOf(col) > -1} />
                      <ListItemText primary={col} />
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>
            <Box sx={{ mt: 2 }}>
              <Button variant="contained" onClick={handleCustomTrain} disabled={loading}>
                Evaluate Custom Dataset
              </Button>
            </Box>
          </Paper>
        )}

        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
            <CircularProgress />
          </Box>
        )}

        {/* Model Evaluation, Charts, and Prediction Section */}
        {results && (
          <Paper sx={{ p: 3, my: 3 }}>
            <Typography variant="h6" gutterBottom>Model Evaluation</Typography>
            <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', mb: 3 }}>
              {Object.entries(results).map(([model, metrics]) => {
                if (model === 'Predictions') return null;
                return (
                  <Paper key={model} sx={{ p: 2, flex: 1, minWidth: 200 }}>
                    <Typography variant="subtitle1" gutterBottom>{model}</Typography>
                    <Typography variant="body2">MSE: {metrics.MSE}</Typography>
                    <Typography variant="body2">R² Score: {metrics["R2 Score"]}</Typography>
                    <Typography variant="body2">Training Time: {metrics["Training Time"]} sec</Typography>
                  </Paper>
                );
              })}
            </Box>

            <Box sx={{ mb: 3 }}>
              <Typography variant="h6" gutterBottom>Graphical Comparison</Typography>
              <Box sx={{ mb: 3 }}>
                <Bar data={barChartData} />
              </Box>
              <Box sx={{ mb: 3 }}>
                <Scatter data={scatterData} />
              </Box>
              <Box sx={{ mb: 3 }}>
                <Line data={lineData} />
              </Box>
              {results["Random Forest"].hasOwnProperty("Feature Importance") && (
                <Box sx={{ mb: 3 }}>
                  <Typography variant="h6" gutterBottom>Random Forest Feature Importance</Typography>
                  <Bar data={featureBarData} />
                </Box>
              )}
            </Box>

            <Box sx={{ mb: 3 }}>
              <Typography variant="h6" gutterBottom>Algorithm Comparison</Typography>
              <Typography variant="body1">
                <strong>Linear Regression:</strong> A simple, interpretable model that assumes a linear relationship between independent features and the target.
              </Typography>
              <Typography variant="body1" sx={{ mt: 2 }}>
                <strong>Random Forest Regressor:</strong> An ensemble method that builds multiple decision trees and aggregates their predictions.
              </Typography>
              <Typography variant="body1" component="div" sx={{ mt: 2 }}>
                <strong>Key Differences:</strong>
                <ul>
                  <li><strong>Complexity:</strong> Linear Regression is simpler; Random Forest can capture complex interactions.</li>
                  <li><strong>Interpretability:</strong> Linear Regression offers clear coefficients, while Random Forest is more of a black box.</li>
                  <li><strong>Performance:</strong> Random Forest often performs better on non-linear data but may be slower to train.</li>
                  <li><strong>Overfitting:</strong> Linear Regression may underfit complex data; Random Forest may overfit if not tuned properly.</li>
                </ul>
              </Typography>
            </Box>

            <Button variant="outlined" onClick={handleDownload}>
              Download Report
            </Button>

            {/* Prediction Section */}
            <Box sx={{ mt: 4, p: 2, border: '1px solid', borderColor: 'grey.300', borderRadius: 1 }}>
              <Typography variant="h6" gutterBottom>Predict Target Value</Typography>
              {predictionSchema.length > 0 ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                  {predictionSchema.map(item => (
                    <Box key={item.name}>
                      {item.type === 'numeric' ? (
                        <TextField
                          label={item.name}
                          value={predictionValues[item.name] || ""}
                          onChange={(e) => handlePredictionInputChange(item.name, e.target.value)}
                          type="number"
                          fullWidth
                        />
                      ) : (
                        <FormControl fullWidth>
                          <InputLabel id={`${item.name}-select-label`}>{item.name}</InputLabel>
                          <Select
                            labelId={`${item.name}-select-label`}
                            value={predictionValues[item.name] || ""}
                            label={item.name}
                            onChange={(e) => handlePredictionInputChange(item.name, e.target.value)}
                          >
                            {item.options.map(option => (
                              <MenuItem key={option} value={option}>{option}</MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      )}
                    </Box>
                  ))}
                  <Button variant="contained" onClick={handlePredict}>Predict</Button>
                  {predictionResult && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="subtitle1">Prediction Results:</Typography>
                      <Typography variant="body2">Linear Regression: {predictionResult["Linear Regression"]}</Typography>
                      <Typography variant="body2">Random Forest: {predictionResult["Random Forest"]}</Typography>
                    </Box>
                  )}
                </Box>
              ) : (
                <Typography variant="body2">No prediction schema available. Please run a model comparison first.</Typography>
              )}
            </Box>
          </Paper>
        )}

        <Snackbar open={!!error} autoHideDuration={6000} onClose={() => setError(null)}>
          <Alert severity="error" sx={{ width: '100%' }}>
            {error}
          </Alert>
        </Snackbar>
      </Container>
    </ThemeProvider>
  );
};

export default App;
