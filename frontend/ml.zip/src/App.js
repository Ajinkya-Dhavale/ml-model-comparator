"use client"

// App.js
import { useState } from "react"
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom"
import { ThemeProvider, createTheme } from "@mui/material/styles"
import {
  CssBaseline,
  Container,
  Box,
  Typography,
  AppBar,
  Toolbar,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from "@mui/material"
import {
  Menu as MenuIcon,
  Home as HomeIcon,
  Compare as CompareIcon,
  School as SchoolIcon,
  Brightness4,
  Brightness7,
} from "@mui/icons-material"
import HomePage from "./pages/HomePage"
import LinearVsRandomForest from "./pages/LinearVsRandomForest"
import RandomForestVsLogistic from "./pages/RandomForestVsLogistic"
import TheoryPage from "./pages/TheoryPage"

const App = () => {
  const [darkMode, setDarkMode] = useState(false)
  const [drawerOpen, setDrawerOpen] = useState(false)

  const theme = createTheme({
    palette: {
      mode: darkMode ? "dark" : "light",
      primary: {
        main: "#3f51b5",
      },
      secondary: {
        main: "#f50057",
      },
    },
    typography: {
      fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
      h4: {
        fontWeight: 600,
      },
      h6: {
        fontWeight: 500,
      },
    },
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            borderRadius: 8,
          },
        },
      },
      MuiPaper: {
        styleOverrides: {
          root: {
            borderRadius: 8,
          },
        },
      },
    },
  })

  const toggleDrawer = (open) => (event) => {
    if (event.type === "keydown" && (event.key === "Tab" || event.key === "Shift")) {
      return
    }
    setDrawerOpen(open)
  }

  const menuItems = [
    { text: "Home", icon: <HomeIcon />, path: "/" },
    { text: "Linear vs Random Forest", icon: <CompareIcon />, path: "/linear-vs-random-forest" },
    { text: "Random Forest vs Logistic", icon: <CompareIcon />, path: "/random-forest-vs-logistic" },
    { text: "ML Theory", icon: <SchoolIcon />, path: "/theory" },
  ]

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
          <AppBar position="static">
            <Toolbar>
              <IconButton edge="start" color="inherit" aria-label="menu" onClick={toggleDrawer(true)} sx={{ mr: 2 }}>
                <MenuIcon />
              </IconButton>
              <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                ML Model Comparator
              </Typography>
              <IconButton color="inherit" onClick={() => setDarkMode(!darkMode)}>
                {darkMode ? <Brightness7 /> : <Brightness4 />}
              </IconButton>
            </Toolbar>
          </AppBar>

          <Drawer anchor="left" open={drawerOpen} onClose={toggleDrawer(false)}>
            <Box sx={{ width: 250 }} role="presentation" onClick={toggleDrawer(false)} onKeyDown={toggleDrawer(false)}>
              <List>
                {menuItems.map((item) => (
                  <ListItem button key={item.text} component={Link} to={item.path}>
                    <ListItemIcon>{item.icon}</ListItemIcon>
                    <ListItemText primary={item.text} />
                  </ListItem>
                ))}
              </List>
              <Divider />
            </Box>
          </Drawer>

          <Container component="main" sx={{ flexGrow: 1, py: 4 }}>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/linear-vs-random-forest" element={<LinearVsRandomForest />} />
              <Route path="/random-forest-vs-logistic" element={<RandomForestVsLogistic />} />
              <Route path="/theory" element={<TheoryPage />} />
            </Routes>
          </Container>

          <Box
            component="footer"
            sx={{ py: 3, px: 2, mt: "auto", backgroundColor: (theme) => theme.palette.grey[200] }}
          >
            <Container maxWidth="sm">
              <Typography variant="body2" color="text.secondary" align="center">
                © {new Date().getFullYear()} ML Model Comparator
              </Typography>
            </Container>
          </Box>
        </Box>
      </Router>
    </ThemeProvider>
  )
}

export default App
