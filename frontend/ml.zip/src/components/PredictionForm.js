"use client"
import { Box, Button, TextField, FormControl, InputLabel, MenuItem, Select, Typography, Divider } from "@mui/material"

const PredictionForm = ({ schema, values, onChange, onPredict, result, isClassification = false }) => {
  return (
    <Box>
      <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {schema.map((item) => (
          <Box key={item.name}>
            {item.type === "numeric" ? (
              <TextField
                label={item.name}
                value={values[item.name] || ""}
                onChange={(e) => onChange(item.name, e.target.value)}
                type="number"
                fullWidth
                size="small"
              />
            ) : (
              <FormControl fullWidth size="small">
                <InputLabel id={`${item.name}-select-label`}>{item.name}</InputLabel>
                <Select
                  labelId={`${item.name}-select-label`}
                  value={values[item.name] || ""}
                  label={item.name}
                  onChange={(e) => onChange(item.name, e.target.value)}
                >
                  {item.options &&
                    item.options.map((option) => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                </Select>
              </FormControl>
            )}
          </Box>
        ))}
        <Button variant="contained" onClick={onPredict} sx={{ mt: 1 }}>
          Predict
        </Button>
      </Box>

      {result && (
        <Box sx={{ mt: 3 }}>
          <Divider sx={{ mb: 2 }} />
          <Typography variant="h6" gutterBottom>
            Prediction Results
          </Typography>
          {isClassification ? (
            <Box>
              <Typography variant="body1" sx={{ mb: 1 }}>
                <strong>Logistic Regression:</strong> {String(result["Logistic Regression"])}
                {result["Logistic Regression Probability"] &&
                  ` (Probability: ${(result["Logistic Regression Probability"] * 100).toFixed(2)}%)`}
              </Typography>
              <Typography variant="body1">
                <strong>Random Forest:</strong> {String(result["Random Forest"])}
                {result["Random Forest Probability"] &&
                  ` (Probability: ${(result["Random Forest Probability"] * 100).toFixed(2)}%)`}
              </Typography>
            </Box>
          ) : (
            <Box>
              <Typography variant="body1" sx={{ mb: 1 }}>
                <strong>Linear Regression:</strong> {String(result["Linear Regression"])}
              </Typography>
              <Typography variant="body1">
                <strong>Random Forest:</strong> {String(result["Random Forest"])}
              </Typography>
            </Box>
          )}
        </Box>
      )}
    </Box>
  )
}

export default PredictionForm
