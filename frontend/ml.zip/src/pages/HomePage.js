import { Link } from "react-router-dom"
import { Box, Button, Card, CardContent, CardMedia, Grid, Paper, Typography, Divider } from "@mui/material"
import { CompareArrows, School, Code } from "@mui/icons-material"

const HomePage = () => {
  return (
    <Box>
      <Paper
        sx={{
          position: "relative",
          backgroundColor: "grey.800",
          color: "#fff",
          mb: 4,
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center",
          backgroundImage: `url(/placeholder.svg?height=400&width=1200)`,
          p: 6,
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            position: "absolute",
            top: 0,
            bottom: 0,
            right: 0,
            left: 0,
            backgroundColor: "rgba(0,0,0,.5)",
            borderRadius: 2,
          }}
        />
        <Grid container>
          <Grid item md={6}>
            <Box
              sx={{
                position: "relative",
                p: { xs: 3, md: 6 },
                pr: { md: 0 },
              }}
            >
              <Typography component="h1" variant="h3" color="inherit" gutterBottom>
                Machine Learning Model Comparison
              </Typography>
              <Typography variant="h5" color="inherit" paragraph>
                Compare different ML algorithms, understand their strengths and weaknesses, and make informed decisions
                for your data science projects.
              </Typography>
              <Button variant="contained" component={Link} to="/linear-vs-random-forest" sx={{ mt: 2 }}>
                Start Comparing
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Paper>

      <Typography variant="h4" gutterBottom sx={{ mb: 4 }}>
        Explore Machine Learning Models
      </Typography>

      <Grid container spacing={4} sx={{ mb: 6 }}>
        <Grid item xs={12} md={4}>
          <Card sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
            <CardMedia
              component="img"
              height="140"
              image="/placeholder.svg?height=140&width=400"
              alt="Linear Regression"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="h2">
                Linear Regression
              </Typography>
              <Typography>
                A fundamental algorithm that models the relationship between a dependent variable and one or more
                independent variables using a linear approach.
              </Typography>
              <Button component={Link} to="/theory" variant="outlined" sx={{ mt: 2 }}>
                Learn More
              </Button>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
            <CardMedia component="img" height="140" image="/placeholder.svg?height=140&width=400" alt="Random Forest" />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="h2">
                Random Forest
              </Typography>
              <Typography>
                An ensemble learning method that constructs multiple decision trees during training and outputs the mean
                prediction of the individual trees.
              </Typography>
              <Button component={Link} to="/theory" variant="outlined" sx={{ mt: 2 }}>
                Learn More
              </Button>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
            <CardMedia
              component="img"
              height="140"
              image="/placeholder.svg?height=140&width=400"
              alt="Logistic Regression"
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography gutterBottom variant="h5" component="h2">
                Logistic Regression
              </Typography>
              <Typography>
                A statistical model that uses a logistic function to model a binary dependent variable, commonly used
                for classification problems.
              </Typography>
              <Button component={Link} to="/theory" variant="outlined" sx={{ mt: 2 }}>
                Learn More
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Divider sx={{ my: 6 }} />

      <Typography variant="h4" gutterBottom sx={{ mb: 4 }}>
        What You Can Do
      </Typography>

      <Grid container spacing={4}>
        <Grid item xs={12} md={4}>
          <Box sx={{ textAlign: "center", p: 2 }}>
            <CompareArrows sx={{ fontSize: 60, color: "primary.main", mb: 2 }} />
            <Typography variant="h6" gutterBottom>
              Compare Models
            </Typography>
            <Typography>
              See how different algorithms perform on the same dataset. Compare metrics like accuracy, precision, and
              training time.
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={12} md={4}>
          <Box sx={{ textAlign: "center", p: 2 }}>
            <School sx={{ fontSize: 60, color: "primary.main", mb: 2 }} />
            <Typography variant="h6" gutterBottom>
              Learn Theory
            </Typography>
            <Typography>
              Understand the mathematical foundations and practical applications of various machine learning algorithms.
            </Typography>
          </Box>
        </Grid>
        <Grid item xs={12} md={4}>
          <Box sx={{ textAlign: "center", p: 2 }}>
            <Code sx={{ fontSize: 60, color: "primary.main", mb: 2 }} />
            <Typography variant="h6" gutterBottom>
              Make Predictions
            </Typography>
            <Typography>
              Use trained models to make predictions on new data and see how different algorithms perform in real-time.
            </Typography>
          </Box>
        </Grid>
      </Grid>
    </Box>
  )
}

export default HomePage
