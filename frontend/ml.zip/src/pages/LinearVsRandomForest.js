"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import {
    Box,
    Button,
    CircularProgress,
    Container,
    Divider,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Paper,
    Select,
    Snackbar,
    Typography,
    Checkbox,
    ListItemText,
    OutlinedInput,
} from "@mui/material"
import { Alert } from "@mui/material"
import { Bar, Scatter, Line } from "react-chartjs-2"
import "chart.js/auto"

const CombinedDragDrop = ({ onFileSelect }) => {
    const handleChange = (e) => {
        if (e.target.files.length > 0) {
            onFileSelect(e.target.files[0])
        }
    }

    return (
        <Paper sx={{ p: 2, border: "2px dashed #aaa", textAlign: "center" }}>
            <Typography variant="subtitle1">Upload your CSV file</Typography>
            <input type="file" accept=".csv" onChange={handleChange} />
        </Paper>
    )
}

const DataPreview = ({ columns, previewData }) => (
    <Box sx={{ mt: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>
            Data Preview:
        </Typography>
        <table border="1" cellPadding="5">
            <thead>
                <tr>
                    {columns.map((col, idx) => (
                        <th key={idx}>{col}</th>
                    ))}
                </tr>
            </thead>
            <tbody>
                {previewData.map((row, i) => (
                    <tr key={i}>
                        {columns.map((col) => (
                            <td key={col}>{row[col]}</td>
                        ))}
                    </tr>
                ))}
            </tbody>
        </table>
    </Box>
)

const PredictionForm = ({ schema, values, onChange, onPredict }) => (
    <Box sx={{ mt: 3 }}>
        <Typography variant="h6">Make a Prediction</Typography>
        <Grid container spacing={2}>
            {schema.map((field, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                    <FormControl fullWidth>
                        <InputLabel>{field.name}</InputLabel>
                        <OutlinedInput
                            label={field.name}
                            value={values[field.name] || ""}
                            onChange={(e) => onChange(field.name, e.target.value)}
                        />
                    </FormControl>
                </Grid>
            ))}
        </Grid>
        <Button variant="contained" sx={{ mt: 2 }} onClick={onPredict}>
            Predict
        </Button>
    </Box>
)

const ModelComparison = ({
    results,
    barChartData,
    scatterData,
    lineData,
    featureBarData,
    predictionSchema,
    predictionValues,
    onPredictionChange,
    onPredict,
    predictionResult,
    onDownload,
}) => {
    if (!results) return null

    return (
        <Box>
            <Typography variant="h6">Model Evaluation</Typography>
            <Box sx={{ mt: 2 }}>
                <Bar data={barChartData} />
            </Box>
            {scatterData && (
                <Box sx={{ mt: 4 }}>
                    <Typography variant="subtitle1">Predicted vs Actual (Scatter Plot)</Typography>
                    <Scatter data={scatterData} />
                </Box>
            )}
            {lineData && (
                <Box sx={{ mt: 4 }}>
                    <Typography variant="subtitle1">Prediction Trends (Line Chart)</Typography>
                    <Line data={lineData} />
                </Box>
            )}
            {featureBarData && (
                <Box sx={{ mt: 4 }}>
                    <Typography variant="subtitle1">Random Forest Feature Importances</Typography>
                    <Bar data={featureBarData} />
                </Box>
            )}
            <PredictionForm
                schema={predictionSchema}
                values={predictionValues}
                onChange={onPredictionChange}
                onPredict={onPredict}
            />
            {predictionResult && (
                <Box sx={{ mt: 2 }}>
                    <Typography variant="body1">
                        <strong>Prediction Results:</strong>
                    </Typography>
                    <Typography>
                        Linear Regression: {predictionResult.linearRegression}
                    </Typography>
                    <Typography>
                        Random Forest: {predictionResult.randomForest}
                    </Typography>
                </Box>
            )}
            <Button variant="outlined" sx={{ mt: 3 }} onClick={onDownload}>
                Download Report (JSON)
            </Button>
        </Box>
    )
}

const LinearVsRandomForest = () => {
    const [results, setResults] = useState(null)
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)

    const [uploadedFile, setUploadedFile] = useState(null)
    const [columns, setColumns] = useState([])
    const [previewData, setPreviewData] = useState([])
    const [targetColumn, setTargetColumn] = useState("")
    const [selectedFeatures, setSelectedFeatures] = useState([])

    const [predictionSchema, setPredictionSchema] = useState([])
    const [predictionValues, setPredictionValues] = useState({})
    const [predictionResult, setPredictionResult] = useState(null)

    const irisCols = ["sepal length (cm)", "sepal width (cm)", "petal length (cm)", "petal width (cm)"]
    const [irisTarget, setIrisTarget] = useState("sepal length (cm)")
    const [irisFeatures, setIrisFeatures] = useState(["sepal width (cm)", "petal length (cm)", "petal width (cm)"])

    useEffect(() => {
        setSelectedFeatures([])
        setPredictionSchema([])
        setPredictionValues({})
    }, [uploadedFile])

    useEffect(() => {
        setSelectedFeatures((prev) => prev.filter((col) => col !== targetColumn))
    }, [targetColumn])

    const handleFileSelect = (file) => {
        if (!file) return
        setUploadedFile(file)
        const reader = new FileReader()
        reader.onload = (e) => {
            const text = e.target.result
            const lines = text.split("\n").filter((line) => line.trim() !== "")
            if (lines.length === 0) return
            const header = lines[0].split(",")
            setColumns(header)
            setTargetColumn(header[header.length - 1])
            setSelectedFeatures(header.slice(0, header.length - 1))
            const preview = lines.slice(1, 6).map((line) => {
                const values = line.split(",")
                const obj = {}
                header.forEach((col, index) => {
                    obj[col] = values[index]
                })
                return obj
            })
            setPreviewData(preview)
        }
        reader.readAsText(file)
    }

    const handleCompareIris = async () => {
        try {
            setLoading(true)
            const response = await axios.get("http://localhost:5000/compare", {
                params: {
                    target: irisTarget,
                    features: irisFeatures.join(","),
                },
            })
            if (response.data.success) {
                setResults(response.data.results)
                if (response.data.prediction_schema) {
                    setPredictionSchema(response.data.prediction_schema)
                    const initVals = {}
                    response.data.prediction_schema.forEach((item) => {
                        initVals[item.name] = ""
                    })
                    setPredictionValues(initVals)
                }
                setError(null)
            } else {
                setError(response.data.error || "Failed to compare models")
            }
        } catch (err) {
            setError(err.response?.data?.error || "Failed to compare models")
        } finally {
            setLoading(false)
        }
    }

    const handleCustomTrain = async () => {
        if (!uploadedFile) return
        try {
            setLoading(true)
            const formData = new FormData()
            formData.append("file", uploadedFile)
            formData.append("target", targetColumn)
            selectedFeatures.forEach((feature) => formData.append("features", feature))
            const response = await axios.post("http://localhost:5000/upload", formData, {
                headers: { "Content-Type": "multipart/form-data" },
            })
            setResults(response.data.results)
            if (response.data.prediction_schema) {
                setPredictionSchema(response.data.prediction_schema)
                const initVals = {}
                response.data.prediction_schema.forEach((item) => {
                    initVals[item.name] = ""
                })
                setPredictionValues(initVals)
            }
            setError(null)
        } catch (err) {
            setError(err.response?.data?.error || "File upload failed")
        } finally {
            setLoading(false)
        }
    }

    const handlePredictionInputChange = (feature, value) => {
        setPredictionValues((prev) => ({ ...prev, [feature]: value }))
    }

    const handlePredict = async () => {
        try {
            const response = await axios.post("http://localhost:5000/predict", { features: predictionValues })
            if (response.data.success) {
                setPredictionResult({
                    linearRegression: response.data.predictions["Linear Regression"],
                    randomForest: response.data.predictions["Random Forest"]
                })
                setError(null)
            } else {
                setError(response.data.error || "Prediction failed")
            }
        } catch (err) {
            setError(err.response?.data?.error || "Prediction failed")
        }
    }

    const handleDownload = () => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(results, null, 2))
        const downloadAnchor = document.createElement("a")
        downloadAnchor.setAttribute("href", dataStr)
        downloadAnchor.setAttribute("download", "model_comparison_report.json")
        document.body.appendChild(downloadAnchor)
        downloadAnchor.click()
        document.body.removeChild(downloadAnchor)
    }

    let barChartData, scatterData, lineData, featureBarData
    if (results) {
        barChartData = {
            labels: ["MSE", "R2 Score", "Training Time"],
            datasets: [
                {
                    label: "Linear Regression",
                    data: [
                        results["Linear Regression"].MSE,
                        results["Linear Regression"]["R2 Score"],
                        results["Linear Regression"]["Training Time"],
                    ],
                    backgroundColor: "rgba(75, 192, 192, 0.6)",
                },
                {
                    label: "Random Forest",
                    data: [
                        results["Random Forest"].MSE,
                        results["Random Forest"]["R2 Score"],
                        results["Random Forest"]["Training Time"],
                    ],
                    backgroundColor: "rgba(153, 102, 255, 0.6)",
                },
            ],
        }

        if (results.Predictions && results.Predictions.Actual) {
            scatterData = {
                datasets: [
                    {
                        label: "Linear Regression",
                        data: results.Predictions.Actual.map((act, i) => ({
                            x: act,
                            y: results.Predictions["Linear Regression"][i],
                        })),
                        backgroundColor: "rgba(75, 192, 192, 0.6)",
                    },
                    {
                        label: "Random Forest",
                        data: results.Predictions.Actual.map((act, i) => ({
                            x: act,
                            y: results.Predictions["Random Forest"][i],
                        })),
                        backgroundColor: "rgba(153, 102, 255, 0.6)",
                    },
                ],
            }

            lineData = {
                labels: results.Predictions.Actual.map((_, i) => i + 1),
                datasets: [
                    {
                        label: "Actual",
                        data: results.Predictions.Actual,
                        borderColor: "rgba(0,0,0,0.6)",
                        fill: false,
                    },
                    {
                        label: "Linear Regression",
                        data: results.Predictions["Linear Regression"],
                        borderColor: "rgba(75, 192, 192, 0.6)",
                        fill: false,
                    },
                    {
                        label: "Random Forest",
                        data: results.Predictions["Random Forest"],
                        borderColor: "rgba(153, 102, 255, 0.6)",
                        fill: false,
                    },
                ],
            }
        }

        if (results["Random Forest"].hasOwnProperty("Feature Importance")) {
            const importance = results["Random Forest"]["Feature Importance"]
            featureBarData = {
                labels: Object.keys(importance),
                datasets: [
                    {
                        label: "Feature Importance",
                        data: Object.values(importance),
                        backgroundColor: "rgba(255, 159, 64, 0.6)",
                    },
                ],
            }
        }
    }

    return (
        <Container maxWidth="lg">
            <Typography variant="h4" gutterBottom>
                Linear Regression vs Random Forest Regression
            </Typography>

            <Grid container spacing={4}>
                <Grid item xs={12} md={6}>
                    <Typography variant="h6">Compare on Iris Dataset</Typography>
                    <FormControl fullWidth sx={{ mt: 2 }}>
                        <InputLabel>Target Column</InputLabel>
                        <Select value={irisTarget} label="Target Column" onChange={(e) => setIrisTarget(e.target.value)}>
                            {irisCols.map((col) => (
                                <MenuItem key={col} value={col}>
                                    {col}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControl fullWidth sx={{ mt: 2 }}>
                        <InputLabel>Feature Columns</InputLabel>
                        <Select
                            multiple
                            value={irisFeatures}
                            onChange={(e) => setIrisFeatures(e.target.value)}
                            input={<OutlinedInput label="Feature Columns" />}
                            renderValue={(selected) => selected.join(", ")}
                        >
                            {irisCols.map((col) => (
                                <MenuItem key={col} value={col}>
                                    <Checkbox checked={irisFeatures.includes(col)} />
                                    <ListItemText primary={col} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <Button variant="contained" sx={{ mt: 2 }} onClick={handleCompareIris}>
                        Compare Models (Iris)
                    </Button>

                    <Divider sx={{ my: 4 }} />

                    
                </Grid>

                <Grid item xs={12} md={6}>
                    <ModelComparison
                        results={results}
                        barChartData={barChartData}
                        scatterData={scatterData}
                        lineData={lineData}
                        featureBarData={featureBarData}
                        predictionSchema={predictionSchema}
                        predictionValues={predictionValues}
                        onPredictionChange={handlePredictionInputChange}
                        onPredict={handlePredict}
                        predictionResult={predictionResult}
                        onDownload={handleDownload}
                    />
                </Grid>
            </Grid>

            <Snackbar open={!!error} autoHideDuration={6000} onClose={() => setError(null)}>
                <Alert severity="error" onClose={() => setError(null)}>
                    {error}
                </Alert>
            </Snackbar>

            {loading && (
                <Box sx={{ textAlign: "center", mt: 4 }}>
                    <CircularProgress />
                </Box>
            )}
        </Container>
    )
}

export default LinearVsRandomForest